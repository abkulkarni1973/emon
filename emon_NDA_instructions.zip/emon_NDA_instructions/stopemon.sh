#!/bin/bash

EMON=/opt/intel/emon/bin64/emon

$EMON -stop